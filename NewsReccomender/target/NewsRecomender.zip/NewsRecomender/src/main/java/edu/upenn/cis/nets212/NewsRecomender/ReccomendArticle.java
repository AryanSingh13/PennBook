package edu.upenn.cis.nets212.NewsRecomender;

import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import com.amazonaws.services.dynamodbv2.document.DynamoDB;
import com.amazonaws.services.dynamodbv2.document.ItemCollection;
import com.amazonaws.services.dynamodbv2.document.QueryOutcome;
import com.amazonaws.services.dynamodbv2.document.Table;
import com.amazonaws.services.dynamodbv2.document.spec.QuerySpec;
import com.amazonaws.services.dynamodbv2.document.utils.ValueMap;
import com.amazonaws.services.dynamodbv2.document.Item;

import edu.upenn.cis.nets212.config.Config;
import edu.upenn.cis.nets212.storage.DynamoConnector;

public class ReccomendArticle {

	public static void main(String[] args) {
		String username = "vibha_makam";
		final String seen = "SeenArticles";
		final String newsGraph = "NewsGraph";
		DynamoDB db = DynamoConnector.getConnection(Config.DYNAMODB_URL);
		Table seenTable = db.getTable("SeenArticles");
		Table graphTable = db.getTable(newsGraph);
		//Get the set of articles already seen by the user
		QuerySpec querySpec = new QuerySpec().withKeyConditionExpression("username =:uu")
				                      .withValueMap(new ValueMap()
				                      .with(":uu", username));
		ItemCollection<QueryOutcome> seenOutcome = seenTable.query(querySpec);
		Iterator<Item>articleNames = seenOutcome.iterator();
		int nextOrd = 0;
		Set<Integer>seenArticles = new HashSet<Integer>();
		while(articleNames.hasNext()) {
			Item articleRec = articleNames.next();
			nextOrd = Math.max(nextOrd, articleRec.getInt("ordNum"));
			seenArticles.add(articleRec.getInt("articleID"));
		}
		nextOrd+=1;
		String queryDate = LocalDate.now().toString().substring(0,4);
		final Map<String,String>expression = new HashMap<String,String>();
		expression.put("#d", "Date");
		QuerySpec spec = new QuerySpec().withKeyConditionExpression("username = :uu")
				                        .withFilterExpression("contains(#d, :dd)")
				                        .withNameMap(expression)
				                        .withValueMap(new ValueMap()
				                        .with(":uu", username)
				                        .with(":dd", queryDate)
				                        );
		ItemCollection<QueryOutcome>articleRecOutcome = graphTable.query(spec);
		double sum = 0;
		Iterator<Item> articleRecIterator = articleRecOutcome.iterator();
		List<Item> validArticles = new ArrayList<Item>();
		while(articleRecIterator.hasNext()) {
			Item articleRec = articleRecIterator.next();
			if(seenArticles.contains(articleRec.getBigInteger("articleID").intValue())) {
				continue;
			}
			sum+=articleRec.getDouble("W");
			validArticles.add(articleRec);
		}
		double numbaLine[] = new double[validArticles.size()];
		double runningSum =0;
		for(int i=0;i<numbaLine.length;i++) {
			//normalize and add to the running sum
			runningSum+=(validArticles.get(i).getDouble("W")/sum);
			numbaLine[i] = runningSum;
		}
		//Pick randomly
		double randNum = Math.random();
		int pickedArticleIndex = 0;
		for(int i=0;i<numbaLine.length;i++) {
			if(numbaLine[i]>randNum) {
				pickedArticleIndex = i;
				break;
			}
		}
		if(validArticles.size()>0) {
		Item pickedArticle = validArticles.get(pickedArticleIndex);
		//Now upload the picked article to the articles seen database
		int articleID = pickedArticle.getInt("articleID");
		Item uploadSeenArticle = new Item().withPrimaryKey("username", username).with("articleID", articleID).with("ordNum", nextOrd);
		seenTable.putItem(uploadSeenArticle);
		}
		
		
		
	}

}