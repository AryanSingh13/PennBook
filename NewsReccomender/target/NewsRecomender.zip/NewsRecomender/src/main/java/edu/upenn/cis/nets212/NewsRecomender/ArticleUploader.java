package edu.upenn.cis.nets212.NewsRecomender;
import com.fasterxml.jackson.core.JsonParseException;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import edu.upenn.cis.nets212.config.Config;
import edu.upenn.cis.nets212.storage.DynamoConnector;

import com.amazonaws.services.dynamodbv2.document.BatchWriteItemOutcome;
import com.amazonaws.services.dynamodbv2.document.DynamoDB;
import com.amazonaws.services.dynamodbv2.document.Item;
import com.amazonaws.services.dynamodbv2.document.ItemCollection;
import com.amazonaws.services.dynamodbv2.model.WriteRequest;
import com.amazonaws.services.dynamodbv2.document.TableWriteItems;


import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.util.Set;
import java.util.HashSet;
import opennlp.tools.stemmer.PorterStemmer;
import opennlp.tools.stemmer.Stemmer;
import opennlp.tools.tokenize.SimpleTokenizer;

public class ArticleUploader {

	public static void main(String[] args) {
		SimpleTokenizer model = SimpleTokenizer.INSTANCE;
		Stemmer stemmer = new PorterStemmer();
		Set<String>stopWords = new HashSet<String>();
		Set<Pair>entries = new HashSet<Pair>();
		BufferedReader stopStream = null;
		try {
			stopStream = new  BufferedReader(new FileReader("src/main/resources/nlp_en_stop_words.txt"));
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		String stopString;
		try {
			while((stopString = stopStream.readLine())!=null) {
				stopWords.add(stopString);
			}
		} catch (IOException e) {
			System.out.println("Corrupted words file");
			e.printStackTrace();
		}
		final String tableName = "searchKeywords";
		DynamoDB db = DynamoConnector.getConnection(Config.DYNAMODB_URL);
		String filePath = "/home/nets212/Downloads/archive/News_Category_Dataset_v2.json";
		BufferedReader reader;
		ObjectMapper mapper = new ObjectMapper();
		try {
			reader = new BufferedReader(new FileReader(filePath));
			String currentLine;
			try {
				int counter=0;
				while((currentLine = reader.readLine())!=null) {					
					Article article  = mapper.readValue(currentLine, Article.class);
					String words[] = model.tokenize(article.getHeadline());
					//Loop through the words and ensure they meet the requirements
					
					for(String word:words)
					{
						String processed = word.toLowerCase();
						if(processed.matches("^[a-zA-Z]*$")&&!(stopWords.contains(word)))
						{
							entries.add(new Pair(stemmer.stem(processed).toString(),counter));
						}
					}
					counter++;
				}
				Iterator<Pair> it = entries.iterator();
				int count = 1;
				ArrayList<Item> items = new ArrayList<Item>();
				//Add 25 items at a time using batchWrite
				//int countah= 0;
				while(it.hasNext()) {
					Pair keywordPair = it.next();
					String word=keywordPair.x;
					int id = keywordPair.y;
					Item item = new Item().withPrimaryKey("keyword", word)
							.with("articleID", id);

							
					items.add(item);
					//Load items into list until we have reached max size for batchWrite
					if(count<25)
					{
						count++;
					}
					if(count>=25 || !it.hasNext())
					{
						try {
							TableWriteItems writeTable = new TableWriteItems(tableName).withItemsToPut(items);
							BatchWriteItemOutcome outcome = db.batchWriteItem(writeTable);
				            while (outcome.getUnprocessedItems().size() > 0) {
				                Map<String, List<WriteRequest>> unprocessedItems = outcome.getUnprocessedItems();
				                if (outcome.getUnprocessedItems().size() > 0){		   
				                    outcome = db.batchWriteItemUnprocessed(unprocessedItems);
				                }
				            }
				            items.clear();
				            count = 1;
						}
						catch(Exception e)
						{
							System.out.println("Falure loading data");
							e.printStackTrace();
						}
					}
				}
				
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

	}

}
class Pair {
	String x;
	int y;
	public Pair(String x, int y) {
		this.x=x;
		this.y=y;
	}
	@Override
	public boolean equals(Object o) {
		Pair other = (Pair)o;
		
		return (this.x.equals(other.x)&&this.y==other.y);
	}
}
class Article{
	private int id;
	private String category;
	private String headline;
	private String authors;
	private String link;
	private String short_description;
	private String date;
	public int getId() {
		return this.id;
	}
	public void setId(int id) {
		this.id=id;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getHeadline() {
		return headline;
	}
	public void setHeadline(String headline) {
		this.headline = headline;
	}
	public String getAuthors() {
		return authors;
	}
	public void setAuthors(String authors) {
		this.authors = authors;
	}
	public String getLink() {
		return link;
	}
	public void setLink(String link) {
		this.link = link;
	}
	public String getShort_description() {
		return short_description;
	}
	public void setShort_description(String short_description) {
		this.short_description = short_description;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	
}
